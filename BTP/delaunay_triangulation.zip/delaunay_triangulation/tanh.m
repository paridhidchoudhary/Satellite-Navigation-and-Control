t0 =5;
t= [-10:10];
x= tanh(exp(-(abs(t)-t0)));
plot(t, x)