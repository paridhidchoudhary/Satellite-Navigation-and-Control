function ad_h_inv= Ad_h_inv(eta_tilde_v)
h=exp(eta_tilde_v);
h_inv=lie_inv(h);
ad_h_inv=adjoint_op(h_inv);
end
